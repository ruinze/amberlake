jQuery(document).ready(function(){
  jQuery('.bxslider').bxSlider({

  	 mode: 'horizontal',
  	 auto: true,
  	 adaptiveHeight: true,
  	 useCSS: true,
  	 responsive: true,
  	 slideWidth: 860,
  	 controls: false,
  	 easing: 'ease-in'
  });
});