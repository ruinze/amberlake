<?php 

function parent_slider_shortcode(){
	ob_start();
	include('template-parts/custom-temp/parentlist.php');
	$content_ret = ob_get_contents();
	ob_end_clean();
	return $content_ret;

}

add_shortcode('parent_slider', 'parent_slider_shortcode');

?>