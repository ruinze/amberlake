<?php
/**
 * Displays footer site info
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>
<div class="site-info">
	<div class="col-md-4">Donated by: MEDIAONE PH </div>
	<div class="col-md-8">
	&copy; <?php echo date('Y'); ?> Davao Autism Intervention Center Foundation. All Rights Reserved

	</div>
</div><!-- .site-info -->
