<ul class="bxslider">
<?php

$the_query = new WP_Query(array('post_type'=>'parent_testimonial'));

foreach ($the_query->posts as $post_value):$the_query->the_post();
	/*echo "<pre>";
	print_r($post_value);
	echo "</pre>";*/
?>
	<li>
		<p class="ps-slider">
			<span class="ps-content" id="pscon"><?php echo $post_value->post_content; ?></span><br />
			<br /><br />
			<span class="ps-content" id="ps-name"><?php echo get_post_meta(get_the_ID(), 'parent_name', true);?></span><br />
			<span class="ps-content" id="ps-cat">Parent</span><br />
		</p>
	</li>
<?php endforeach; ?>


</ul>