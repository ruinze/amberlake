<?php 
 ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php echo do_shortcode('[rev_slider alias="homebanner"]'); ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
	<section class="first-content">
		<div class="row div-limiter">
			<div class="col-md-6"><img src="<?php echo get_field("image_1");?>" class="autism-img"></div>
			<div class="col-md-6">
				<div class="row content-header">Autism Spectrum Disorder</div>
				<div class="row content-desc"><?php echo get_post_meta(get_the_ID(), 'autism_description', true);?>
				</div>
				<div class="row content-link"><button class="slider-link">Learn More </button></div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="col-md-12 home-post-slider">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/quotes.png" class="imgqoutes"/>
			<?php echo do_shortcode('[parent_slider]'); ?>
		</div>
		<div class="clearfix"></div>
		<div class="content-logo">
			
			<?php the_custom_logo(); ?>
		</div>
	</section>
		
	</div><!-- .entry-content -->
</article><!-- #post-## -->
