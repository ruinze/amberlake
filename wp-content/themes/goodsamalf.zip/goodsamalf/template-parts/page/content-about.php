<?php 
 ?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<div class="nobanner-header">
			<h1 class="site-title">
			About Davao Autism Intervention Center Foundation
			</h1>
		</div>
	</header><!-- .entry-header -->
	<div class="entry-content">
	<section class="first-content">
		<div class="row div-limiter">
			<div class="col-md-2"><img src="<?php echo get_field("image_1");?>" class="autism-img"></div>
			<div class="col-md-10">
				<div class="row content-desc comdesc"><?php
						the_content();

						wp_link_pages( array(
							'before' => '<div class="page-links">' . __( 'Pages:', 'twentyseventeen' ),
							'after'  => '</div>',
						) );
					?>
				</div>
			</div>
			<div class="col-md-12">
				<div class="row vmg">
					
					<div class="col-md-4">
						<p class="content-header">Vision</p>
						<p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'vision', true);?></p>
					</div>
					<div class="col-md-4">
					  <p class="content-header">Mission</p>
					  <p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'mission', true);?></p>
					</div>
					<div class="col-md-4">
					   <p class="content-header">Goals</p>
					   <p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'goals', true);?></p>
					</div>
				</div>
			</div>

			<div class="col-md-12 officers">
				<div class="col-md-12 content-header">The board of trustees</div>
				<div class="col-md-6">
					<img src="<?php echo get_field("president_image");?>" class="autism-img">
				</div>
				<div class="col-md-6">
					<p class="content-header"><?php echo get_post_meta(get_the_ID(), 'president', true);?></p>
					<p>President</p>
					<p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'president_intro', true);?></p>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-3">
					<img src="<?php echo get_field("vice_pres_image");?>" class="autism-img">
					<p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'vice_president', true);?></p>
					<p>Vice-President</p>
				</div>
				<div class="col-md-3">
					<img src="<?php echo get_field("sec_image");?>" class="autism-img">
					<p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'secretary', true);?></p>
					<p>Vice-President</p>
				</div>
				<div class="col-md-3">
					<img src="<?php echo get_field("treasurer_image");?>" class="autism-img" class="imgofficer">
					<p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'treasurer', true);?></p>
					<p>Vice-President</p>
				</div>
				<div class="col-md-3">
					<img src="<?php echo get_field("auditor_image");?>" class="autism-img">
					<p class="content-desc"><?php echo get_post_meta(get_the_ID(), 'auditor_name', true);?></p>
					<p>Vice-President</p>
				</div>
				

			</div>

		</div><!-- div limiter -->
		<div class="clearfix"></div>
		<div class="col-md-12 home-post-slider">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/quotes.png" class="imgqoutes"/>
			<?php echo do_shortcode('[parent_slider]'); ?>
		</div>
		<div class="clearfix"></div>
		<div class="content-logo">
			
			<?php the_custom_logo(); ?>
		</div>
	</section>
		
	</div><!-- .entry-content -->
</article><!-- #post-## -->
